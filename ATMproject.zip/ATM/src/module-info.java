module ATM {
	requires java.desktop;
	requires java.sql;
}