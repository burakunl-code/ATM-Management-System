package ATM;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class UserData {
	
	private int ID;
	
	public UserData(boolean newAcc,Database database) {
		if(newAcc) ID = UsersDatabase.getNextID(database);
		JFrame frame = new JFrame("ATM");
		frame.setLayout(new BorderLayout());
		
		JLabel title = GUIConstants.jLabel("Welcome to ATM", 30);
		title.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
		frame.add(title,BorderLayout.NORTH);
		
		JPanel panel =new JPanel(new GridLayout(9,2,15,15));
		panel.setBackground(null);
		panel.setBorder(BorderFactory.createEmptyBorder(10,30,30,30));
		
		JLabel lb1 = GUIConstants.jLabel("ID:", 23);
		panel.add(lb1);
		JLabel id = GUIConstants.jLabel(String.valueOf(ID), 23);
		panel.add(id);
		JLabel lb2 = GUIConstants.jLabel("First Name:", 23);
		panel.add(lb2);
		JTextField firstName = GUIConstants.jTextField();
		panel.add(firstName);
		JLabel lb3 = GUIConstants.jLabel("Last Name:", 23);
		panel.add(lb3);
		JTextField lastName = GUIConstants.jTextField();
		panel.add(lastName);
		JLabel lb4 = GUIConstants.jLabel("Birth Date (yyyy-dd-MM):", 23);
		panel.add(lb4);
		JTextField birthDate = GUIConstants.jTextField();
		panel.add(birthDate);
		JLabel lb5 = GUIConstants.jLabel("Email:", 23);
		panel.add(lb5);
		JTextField email = GUIConstants.jTextField();
		panel.add(email);
		JLabel lb6 = GUIConstants.jLabel("Phone Number:", 23);
		panel.add(lb6);
		JTextField phoneNumber = GUIConstants.jTextField();
		panel.add(phoneNumber);
		JLabel lb7 = GUIConstants.jLabel("PIN Code:", 23);
		panel.add(lb7);
		JPasswordField pincode = GUIConstants.jPasswordField();
		panel.add(pincode);
		JLabel lb8 = GUIConstants.jLabel("Confirm PIN Code:", 23);
		panel.add(lb8);
		JPasswordField confirmpincode = GUIConstants.jPasswordField();
		panel.add(confirmpincode);
		
		JButton confirm = GUIConstants.jButton("Contine");
		
		
		if(newAcc) {
			
			JButton login = GUIConstants.jButton("Alread have an account");
			login.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					new Login(database);
					frame.dispose();
					
				}
				
			});
			panel.add(login);
		
			
			confirm.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					
				
					String firstNameIn = firstName.getText();
					String lastNameIn = lastName.getText();
					String birthDateIn = birthDate.getText();
					String emailIn = email.getText();
					String phoneNumberIn = phoneNumber.getText();
					int PINCodeIn, confirmPINCodeIn;
					
					if (firstNameIn.equals("")) {
						JOptionPane.showMessageDialog(frame, "First Name cannot be empty");
						return;
					}
					if (lastNameIn.equals("")) {
						JOptionPane.showMessageDialog(frame, "Last Name cannot be empty");
						return;
					}
					if (birthDateIn.equals("")) {
						JOptionPane.showMessageDialog(frame, "Birth Date cannot be empty");
						return;
					}
					try {
						LocalDate.parse(birthDate.getText(),DateTimeFormatter.ofPattern("yyyy-dd-MM"));
					}catch(Exception e2) {
						JOptionPane.showMessageDialog(frame, "Birth date doesn't match");
						return;
					}
					if (emailIn.equals("")) {
						JOptionPane.showMessageDialog(frame, "Email cannot be empty");
						return;
					}
					if (phoneNumberIn.equals("")) {
						JOptionPane.showMessageDialog(frame, "Phone Number cannot be empty");
						return;
					}
					try {
						PINCodeIn = Integer.parseInt(pincode.getText());
						confirmPINCodeIn = Integer.parseInt(confirmpincode.getText());
					}catch(Exception e1) {
						JOptionPane.showMessageDialog(frame, "PIN Code must be 4 digits (int)");
						return;
					}
					
					if (PINCodeIn!=confirmPINCodeIn) {
						JOptionPane.showMessageDialog(frame, "PIN Code doestn't match it");
						return;
					}
					
					
					
					
					User user = new User();
					user.setID(ID);
					user.setFirstName(firstNameIn);
					user.setLastName(lastNameIn);
					user.setBirthDate(birthDateIn);
					user.setEmail(emailIn);
					user.setPhoneNumber(phoneNumberIn);
					user.setPINCode(PINCodeIn);
					user.setBalance(0);
					UsersDatabase.CreateNewAcc(user,database);
					new List(database, user);
					frame.dispose();
					
				}
				
			});	
		}else {
				JButton cancel = GUIConstants.jButton("Cancel");
				cancel.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						frame.dispose();
						
					}
					
				});
				panel.add(cancel);
				
				confirm.addActionListener(new ActionListener(){

					@Override
					public void actionPerformed(ActionEvent e) {
//						String
						
					}
					
				});
		}
		panel.add(confirm);
		frame.add(panel,BorderLayout.CENTER);
		
		
		frame.setSize(750,720);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setBackground(GUIConstants.backgroundColor);
		frame.setVisible(true);
	}

}
