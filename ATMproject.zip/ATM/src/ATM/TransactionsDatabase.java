package ATM;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TransactionsDatabase {
	
	private static ArrayList<Transaction> getAllTransactions(Database database){
		ArrayList<Transaction> transactions = new ArrayList<>();
		ArrayList<Integer> usersIDs = new ArrayList<>();
		String select = "SELECT * FROM `transactions`.`new_table`;";
		try {
			ResultSet rs = database.getStatement().executeQuery(select);
			while (rs.next()) {
				Transaction t = new Transaction();
				t.setID(rs.getInt("ID"));
				t.setAmount(rs.getDouble("Amount"));
				t.setDateTime(rs.getString("DateTime"));
				usersIDs.add(rs.getInt("UserID"));
				transactions.add(t);
			}
			for(int i = 0;i<transactions.size();i++) {
				User user = UsersDatabase.getUserByID(usersIDs.get(i), i, database);
				transactions.get(i).setUser(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transactions;
		
	}
	public static int getNextID(Database database) {
		int ID = 0;
		ArrayList<Transaction> transactions = getAllTransactions(database);
		int size = transactions.size();
		if (size!=0) {
			Transaction last = transactions.get(size-1);
			ID = last.getID()+1;
		}
		return ID;
	}
	public static void saveTransaction(Transaction t,Database database) {
		String insert = "INSERT INTO `transactions`.`new_table` (`ID`, `Amount`, `DateTime`, `UserID`) "
	              + "VALUES ('" + t.getID() + "', '" + t.getAmount() + "', '" + t.getDateTime() + "', '" + t.getUser().getID() + "');";
		try {
			database.getStatement().execute(insert);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    
	}

}
