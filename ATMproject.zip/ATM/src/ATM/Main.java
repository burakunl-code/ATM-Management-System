package ATM;

public class Main {

	public static void main(String[] args) {
		Database database = new Database();
		new Login(database);
		
		

	}

}
